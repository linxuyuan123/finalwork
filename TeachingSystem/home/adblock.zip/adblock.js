window.onload = function() {

  var l1 = document.getElementById("l1");
  var l2 = document.getElementById("l2");
  l1.style.left = document.body.clientWidth * 2/5 + "px";
  l2.style.left = document.body.clientWidth * 4/5 + "px";

  window.onresize = function(){
    var l1 = document.getElementById("l1");
    var l2 = document.getElementById("l2");
    l1.style.left = document.body.clientWidth * 2/5 + "px";
    l2.style.left = document.body.clientWidth * 4/5 + "px";
  };
};
$(function(){
  var adblock = new ChromeWebUIApis({
    methods: 'requestBlockList',
    onerror: function(ev){
      console.log('error:', arguments);
    },
    onbefore: function(ev){
    },
    onbeforeCallback: function(ev){
    },
    onafterCallback: function(ev){
    }
  });

  /**
   * @method get
   * @param key {String}
   * @desc get param for location.href
   */
  function get(key){
    var reg = new RegExp(key+'=([^&$]*)(?:&|$)','i');
    var rets = reg.exec(location.href);
    return rets && rets[1];
  }

  var tmplFn = doT.template($('#adblock-tmpl').html());
  adblock.requestBlockList(parseInt(get('f')), parseInt(get('t')), function(dict, items){
    $('#srcurl a').attr('href', dict.url).html(dict.url);
    $('#adblockText').html(tmplFn(items));
  });

  
});
